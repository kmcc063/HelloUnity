﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sketch : MonoBehaviour {

    public GameObject myPreFab;

	// Use this for initialization
	void Start () {
        var newCube = (GameObject)Instantiate(myPreFab, new Vector3(3, 5, 0), Quaternion.identity);
        newCube.GetComponent<CubeScript>().SetSize(1.5f);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
